========================================
  RV Car Solutions - Instalador v2.0.0
========================================

INSTALACAO RAPIDA:
==================

1. Faca upload deste ZIP para public_html/
2. Extraia o arquivo
3. Acesse: https://seudominio.com.br/install/
4. Siga os 4 passos na tela
5. DELETE a pasta /install/ apos concluir!

REQUISITOS:
===========
- PHP 7.4 ou superior
- MySQL 5.7 ou superior
- Extensoes: mysqli, json, mbstring
- Permissoes de escrita

ESTRUTURA:
==========
/index.html       - Pagina principal
/assets/          - CSS, JS, Imagens
/api/             - Backend PHP
/install/         - Instalador web (DELETE apos instalar!)

CREDENCIAIS PADRAO:
===================
URL: https://seudominio.com.br/admin/login
Usuario: admin
Senha: rvcar2024

IMPORTANTE: Altere a senha apos o login!

DOCUMENTACAO COMPLETA:
======================
install/GUIA-INSTALADOR.md

SUPORTE:
========
WhatsApp: (47) 98448-5492
Email: contato@rvcarlocacoes.com.br
GitHub: https://github.com/betinhochagas/rvcar

Desenvolvido com amor para RV Car Solutions
Blumenau - Santa Catarina
